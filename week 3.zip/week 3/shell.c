#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <string.h>

#define BUFFER 1024

char** split(char* line){  
    char *token = strtok(line, " "); 
    char **words = malloc(8*sizeof(char*));
    int i = 0;
    while (token != NULL) 
    { 
        words[i] = token; 
        token = strtok(NULL, " ");
        i++; 
    } 
  	words[i] = (char*)0;
    return words; 
}

int main(void) {
    char line[BUFFER];
	char **args = malloc(8*sizeof(char*));
    while(1) {
        printf("$ ");
        if(!fgets(line, BUFFER, stdin)) break;
        //if(!scanf("%s",line)) break;
        char *p = strchr(line, '\n');
        if (p) *p = 0;
        if(strcmp(line, "exit")==0) break;
        args = split(line);
   		int pid= fork();              //fork child
        if(pid==0) {               //Child
            execvp(args[0], args);
            perror("exec");
            exit(1);
        } else {                    //Parent
            wait(NULL);
        }
        
        
    }

    return 0;
}
