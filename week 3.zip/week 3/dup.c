#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<fcntl.h>

int main()
{
	int file_ds = open("tricky.txt", O_WRONLY|O_APPEND);
	dup2(file_ds ,1);
	
	printf("file discripter is copying written in file file tricky.txt\n");
	return 0;
}
