#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<string.h>

int main()
{
	int fd[2],nbytes;
	int cp;
	char string[]="Hello_World\n";
	char read_buff[80];
	pipe(fd);
	cp = fork();
	if(cp==-1){
		perror("error\n");
	}
	else if(cp == 0){
		printf("Child process here\n");
		close(fd[0]);
		write(fd[1] ,string, strlen(string)+1);
		//exit(0);
	}
	else{
		close(fd[1]);
		nbytes = read(fd[0] ,read_buff,sizeof(read_buff));
		printf("Recieved string =%s\n",read_buff);
		return 0;
	}
		
}
