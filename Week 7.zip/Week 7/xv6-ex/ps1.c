#include "type.h"
#include "stat.h"
#include "user.h"
int 
main()
{
	cps();
	exit();
}
