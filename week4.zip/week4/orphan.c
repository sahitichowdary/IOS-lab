#include <stdlib.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include<stdio.h>
int main() 
{ 
  
    int pid =fork(); 
  
    // Parent process 
   // printf("%d",pid); 
    if (pid > 0)
   {
    	printf("Inside parent process pid : %d\n ppid: %d\n",getpid(),getppid());
        sleep(30);
   }
    // Child process 
    else if(pid==0)
    {
    	printf("Inside child process pid : %d\n ppid: %d\n",getpid(),getppid());        
        exit(0); 
    }
    return 0; 
} 
