#include <stdlib.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include<stdio.h>
int main() 
{ 
  
    int pid =fork(); 
  	char ch;
    // Parent process  
    if (pid > 0) {
    for(ch = 'A';ch<='Z';ch++){
    		printf("  %c",ch);
            
    	} 
    	printf("\n");
    	sleep(2);
    		
    	
  }
    // Child process 
    else{
    	printf("Inside child process pid : %d\n ppid: %d\n",getpid(),getppid());    
    	for(ch = 'a';ch<='z';ch++){
    		printf("  %c",ch);
    	}    
    	printf("\n");
        
        exit(0); 
  }
    return 0; 
} 
