#include <stdlib.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include<stdio.h>

int a = 10;
int main() 
{ 
  
    int pid =fork(); 
  	int b=20;
    
    // Parent process  
    if (pid > 0) {
    	
    	printf("Inside parent process pid : %d\n ppid: %d   int value : %d int value : %d\n",getpid(),getppid(),a,b);
        sleep(3);
  }
    // Child process 
  
    else{
      //a=30;
    	printf("Inside child process pid : %d\n ppid: %d    int value = %d int value : %d\n",getpid(),getppid(),a,b);        
        exit(0); 
  }
    //printf("%d\n",a );
    return 0; 
} 
