#include<stdio.h>
//#include"header.h"
int sn(){
	printf("This is 2nd\n");
}
