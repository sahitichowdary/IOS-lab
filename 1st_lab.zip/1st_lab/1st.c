#include<stdio.h>
//#include"header.h"
int main(){
	sn();
	printf("Helll world\n");
}
